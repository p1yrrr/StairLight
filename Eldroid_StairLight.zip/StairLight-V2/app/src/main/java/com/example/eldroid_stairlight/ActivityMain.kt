package com.example.eldroid_stairlight

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ActivityMain : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val logoutBtn = findViewById<Button>(R.id.logout_btn)
        logoutBtn.setOnClickListener {
            val intent = Intent(this, ActivityLogin::class.java)
            startActivity(intent)
            finish()
        }

        val voiceFab = findViewById<FloatingActionButton>(R.id.voice_assistant_fab)
        val voiceModal = findViewById<View>(R.id.voice_modal_overlay)
        val closeVoiceModal = findViewById<ImageButton>(R.id.close_voice_modal)

        voiceFab.setOnClickListener {
            voiceModal.visibility = View.VISIBLE
        }

        closeVoiceModal.setOnClickListener {
            voiceModal.visibility = View.GONE
        }

        voiceModal.setOnClickListener {
            voiceModal.visibility = View.GONE
        }
    }
}
