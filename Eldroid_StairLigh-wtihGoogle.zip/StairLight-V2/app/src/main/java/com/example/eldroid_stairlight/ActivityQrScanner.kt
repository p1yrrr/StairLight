package com.example.eldroid_stairlight

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ActivityQrScanner : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var scanStatus: TextView
    private lateinit var btnStartScan: Button
    private lateinit var btnCloseQr: ImageButton
    private lateinit var cameraExecutor: ExecutorService
    private var isScanning = false

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) startCamera()
            else scanStatus.text = "Camera permission denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_scanner)

        // Initialize Views (based on your XML IDs)
        previewView = findViewById(R.id.previewView)
        scanStatus = findViewById(R.id.tv_scan_status)
        btnStartScan = findViewById(R.id.btn_start_scan)
        btnCloseQr = findViewById(R.id.btn_close_qr)

        cameraExecutor = Executors.newSingleThreadExecutor()

        // Close QR scanner and go back to ActivityMain
        btnCloseQr.setOnClickListener {
            val intent = Intent(this, ActivityMain::class.java)
            startActivity(intent)
            finish()
        }

        // Request permission and initialize camera
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        // Start scanning when button is clicked
        btnStartScan.setOnClickListener {
            if (!isScanning) {
                scanStatus.text = "Scanning..."
                isScanning = true
            } else {
                scanStatus.text = "Scan paused"
                isScanning = false
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
            } catch (exc: Exception) {
                scanStatus.text = "Camera start failed: ${exc.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
